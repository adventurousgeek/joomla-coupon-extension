<?php
/**
 * @component CmCoupon
 * @copyright Copyright (C) Seyi Cmfadeju - All rights reserved.
 * @license : GNU/GPL
 * @Website : http://cmdev.com
 **/

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

class CmcouponSiteViewCoupondelete extends CmCouponSiteViewConnect {
	
	public function display($tpl = null) {
		
		parent::display($tpl);
	}

}
