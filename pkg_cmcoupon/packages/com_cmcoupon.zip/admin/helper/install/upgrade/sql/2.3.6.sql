/*
 * @component CmCoupon
 * @copyright Copyright (C) Seyi Cmfadeju - All rights reserved.
 * @license : GNU/GPL
 * @Website : http://cmdev.com
 **/

 
 
ALTER TABLE #__cmcoupon_profile ADD COLUMN `cc_purchaser` TINYINT AFTER `bcc_admin`;
