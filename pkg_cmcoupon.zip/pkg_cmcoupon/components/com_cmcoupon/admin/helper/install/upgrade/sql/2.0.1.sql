/*
 * @component CmCoupon
 * @copyright Copyright (C) Seyi Cmfadeju - All rights reserved.
 * @license : GNU/GPL
 * @Website : http://cmdev.com
 **/
 
 ALTER TABLE #__cmcoupon_vm ADD COLUMN `params` TEXT;
