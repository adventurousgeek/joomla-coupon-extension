
var $ES=function(a,b){return($(b)||document).getElements(a);};
function $extend(c,a){for(var b in (a||{})){c[b]=a[b];}return c;}
var $E=function(a,b){return($(b)||document).getElement(a);}
