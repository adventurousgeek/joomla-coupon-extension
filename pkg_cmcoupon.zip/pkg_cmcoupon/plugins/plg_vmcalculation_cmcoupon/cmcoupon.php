<?xml version="1.0" encoding="UTF-8" ?>
<extension type="plugin" version="2.5" method="upgrade" group="vmcalculation">
	<name>VmCalculation - CmCoupon</name>
	<creationDate>2013-10-31</creationDate>
	<author>Seyi Cmfadeju</author>
	<copyright>Copyright (C) Seyi Cmfadeju - All rights reserved.</copyright>
	<license>http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL</license>
	<authorEmail>dev@cmfadeju.com</authorEmail>
	<authorUrl>http://cmdev.com</authorUrl>
	<version>2.0.1</version>
	<description>CmCoupon for Virtuemart</description>
	<files>
		<filename plugin="cmcoupon">cmcoupon.php</filename>
	</files>
	<scriptfile>script.php</scriptfile>
</extension>
